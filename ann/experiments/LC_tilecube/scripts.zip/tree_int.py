import numpy as np, struct, math, hashlib, time
p="/mnt/user-data/attachments/ff6529cf-50c6-5af9-9e9f-bff721559dca/f8b0b9b6-ann_index.f16"
raw=open(p,"rb").read(); _,_,dim,n,_=struct.unpack("<5I",raw[8:28])
V=np.frombuffer(raw[28:28+n*dim*2],dtype=np.float16).reshape(n,dim).astype(np.float32)
Vn=V/np.linalg.norm(V,axis=1,keepdims=True)
Vi=np.rint(V*np.float32(8192)).astype(np.int64)          # f16 -> int, exact power-of-2 scale, ties-to-even
assert np.abs(Vi).max()<32768
rng=np.random.default_rng(7); qi=rng.choice(n,200,replace=False)
keep=np.ones(n,bool); keep[qi]=False
N=int(keep.sum()); K_=10; CAP=1000
Xf,Qf=Vn[keep],Vn[qi]
truth=[set(np.argsort(-(Xf@q))[:K_]) for q in Qf]
def kfor(n_): k=math.ceil(n_/1000); return (k+3)//4*4

class FloatB:
    def __init__(s,perm=None):
        s.X=Xf if perm is None else Xf[:,perm].copy(); s.Q=Qf if perm is None else Qf[:,perm].copy()
    def dist(s,A,C): return (A**2).sum(1)[:,None]-2*A@C.T+(C**2).sum(1)[None,:]
    def mean(s,Xs): return Xs.mean(0)
    def dot(s,A,q): return A@q
class IntB:
    def __init__(s,perm=None):
        X=Vi[keep]; Q=Vi[qi]
        s.X=X if perm is None else X[:,perm].copy(); s.Q=Q if perm is None else Q[:,perm].copy()
    def dist(s,A,C):                                    # float64 BLAS on integers < 2^53 is exact in any summation order
        ab=(A.astype(np.float64)@C.T.astype(np.float64)); assert np.abs(ab).max()<2**52
        return (A*A).sum(1)[:,None]-2*ab.astype(np.int64)+(C*C).sum(1)[None,:]
    def mean(s,Xs): c=len(Xs); return (Xs.sum(0,dtype=np.int64)+c//2)//c
    def dot(s,A,q): return (A.astype(np.float64)@q.astype(np.float64)).astype(np.int64)

def lloyd(B,Xs,K,it=25):
    C=Xs[np.array([i*(len(Xs)-1)//(K-1) for i in range(K)])].copy()
    for _ in range(it):
        a=B.dist(Xs,C).argmin(1)
        for k in range(K):
            s=a==k
            if s.any(): C[k]=B.mean(Xs[s])
    return C
def split_pivot(B,Xs,b):
    pr=B.dot(Xs,Xs[b]-Xs[0]); o=np.argsort(pr,kind="stable"); a=np.zeros(len(Xs),int); a[o[len(Xs)//2:]]=1; return a
def two_means(B,Xs):
    b=int(B.dist(Xs,Xs[:1])[:,0].argmax()); C=np.stack([Xs[0],Xs[b]]).copy()
    for _ in range(15):
        a=B.dist(Xs,C).argmin(1)
        if a.min()==a.max(): a=split_pivot(B,Xs,b)
        for k in (0,1): C[k]=B.mean(Xs[a==k])
    a=B.dist(Xs,C).argmin(1)
    if a.min()==a.max(): a=split_pivot(B,Xs,b)
    return C,a
class Node:
    def __init__(s,path,cent): s.path=path; s.cent=cent; s.kids=None; s.rows=[]
class Tree:
    def __init__(s,B): s.B=B; s.roots=None
    def descend(s,v):
        B=s.B; nd=s.roots[int(B.dist(v[None],s.rootC).argmin())]
        while nd.kids: nd=nd.kids[int(B.dist(v[None],np.stack([k.cent for k in nd.kids])).argmin())]
        return nd
    def leaves(s):
        out=[];st=list(s.roots)
        while st:
            nd=st.pop()
            if nd.kids: st+=nd.kids
            else: out.append(nd)
        return sorted(out,key=lambda x:x.path)
    def add_batch(s,rows):
        B=s.B; rows=sorted(rows)
        if s.roots is None:
            K=kfor(len(rows)); C=lloyd(B,B.X[rows],K); s.rootC=C; s.roots=[Node(str(i),C[i]) for i in range(K)]
        for r in rows: s.descend(B.X[r]).rows.append(r)
        again=True
        while again:
            again=False
            for lf in s.leaves():
                if len(lf.rows)>CAP:
                    rs=sorted(lf.rows); C,a=two_means(B,B.X[rs])
                    lf.kids=[Node(lf.path+"."+str(j),C[j]) for j in (0,1)]
                    for r,j in zip(rs,a): lf.kids[j].rows.append(r)
                    lf.rows=[]; again=True
    def addr(s): return {r:lf.path for lf in s.leaves() for r in lf.rows}
def digest(a): return hashlib.sha256(",".join(f"{r}:{a[r]}" for r in sorted(a)).encode()).hexdigest()[:12]
S4=[N//4,N//2,3*N//4,N]
def build(B,shuffle=False):
    t=Tree(B); prev=0
    for e in S4:
        rows=list(range(prev,e))
        if shuffle: np.random.default_rng(e).shuffle(rows)
        t.add_batch(rows); prev=e
    return t
def recall(t,b):
    B=t.B; lv=t.leaves(); C=np.stack([l.cent for l in lv]); rec=[];sc=[]
    for qv,tr in zip(B.Q,truth):
        o=B.dist(qv[None],C)[0].argsort()[:b]; ids=np.concatenate([np.array(lv[i].rows,int) for i in o if lv[i].rows])
        top=ids[np.argsort(-B.dot(B.X[ids],qv),kind="stable")[:K_]]
        rec.append(len(tr&set(top.tolist()))/K_); sc.append(len(ids))
    return np.mean(rec),np.mean(sc)
T0=time.time()
tf=build(FloatB()); af=tf.addr(); print(f"float tree: leaves {len(tf.leaves())} digest {digest(af)}  ({time.time()-T0:.0f}s)")
ti=build(IntB()); ai=ti.addr(); print(f"int tree:   leaves {len(ti.leaves())} digest {digest(ai)}  ({time.time()-T0:.0f}s)")
same=np.mean([af[r]==ai[r] for r in range(N)]); root=np.mean([af[r].split('.')[0]==ai[r].split('.')[0] for r in range(N)])
pref=np.mean([af[r].startswith(ai[r]) or ai[r].startswith(af[r]) for r in range(N)])
print(f"\n[A] int vs float address agreement: identical {100*same:.1f}% | same root {100*root:.1f}% | one is prefix of the other {100*pref:.1f}%")
print("\n[B] bit-exactness")
perm=np.random.default_rng(5).permutation(dim)
ti2=build(IntB(perm)); print(" int, feature order permuted (different summation order): digest equal ->",digest(ti2.addr())==digest(ai))
ti3=build(IntB(),shuffle=True); print(" int, shuffled insert order inside batches: digest equal ->",digest(ti3.addr())==digest(ai))
tf2=build(FloatB(perm)); a2=tf2.addr(); print(f" float32, feature order permuted: digest equal -> {digest(a2)==digest(af)} ; rows with different address: {sum(af[r]!=a2[r] for r in range(N))}")
# decision-level risk proxy: nearest-leaf decisions float32 vs float64
lv=tf.leaves(); C32=np.stack([l.cent for l in lv]); B=FloatB()
d32=B.dist(B.X,C32); d64=B.dist(B.X.astype(np.float64),C32.astype(np.float64))
dis=int((d32.argmin(1)!=d64.argmin(1)).sum()); srt=np.sort(d64,1); gap=(srt[:,1]-srt[:,0])
print(f" nearest-leaf decisions where float32 != float64: {dis}/{N}; smallest best-vs-second gap {gap.min():.2e}; decisions within 1e-5: {(gap<1e-5).sum()}")
Bi=IntB(); di=Bi.dist(Bi.X,np.stack([l.cent for l in ti.leaves()])); si=np.sort(di,1); print(f" int tree: smallest best-vs-second gap {int((si[:,1]-si[:,0]).min())} (integer units, ties broken by lowest index)")
print("\n[C] seek recall@10 (b leaves): int tree | float tree")
for b in (1,2,3,5):
    ri,si_=recall(ti,b); rf,sf=recall(tf,b)
    print(f" b={b}: int {ri:.3f} @ {100*si_/N:.1f}%  |  float {rf:.3f} @ {100*sf/N:.1f}%")
print(f"\ncentroid storage: int centroids fit int16: {bool(max(np.abs(l.cent).max() for l in ti.leaves())<32768)}; per-vector storage 384x2 B = 768 B")
