import numpy as np

D, N, NQ, K = 1024, 20000, 200, 10
rng = np.random.default_rng(1)
cent = rng.standard_normal((50, D))
X = cent[rng.integers(0, 50, N)] + 0.5 * rng.standard_normal((N, D)) + 2.0 * rng.standard_normal(D)  # shared mean = anisotropy
X = X.astype(np.float32)
Xn = X / np.linalg.norm(X, axis=1, keepdims=True)
Q = Xn[rng.choice(N, NQ, replace=False)] + 0.02 * rng.standard_normal((NQ, D)).astype(np.float32)
Q /= np.linalg.norm(Q, axis=1, keepdims=True)
truth = [set(np.argsort(-(Xn @ q))[:K]) for q in Q]
mu = Xn.mean(0)


def angles(V, P):
    U = (V - mu) @ P
    U /= np.linalg.norm(U, axis=1, keepdims=True) + 1e-9
    th = np.degrees(np.arccos(np.clip(U[:, 2], -1, 1)))
    ph = np.degrees(np.arctan2(U[:, 1], U[:, 0])) % 360
    return th, ph


def cells(th, ph, deg, off):
    return ((th + off) // deg).astype(int), (((ph + off) % 360) // deg).astype(int)


def run(L, deg, rotate):
    nphi = int(np.ceil(360 / deg))
    Ps = [np.random.default_rng(100 + (l if rotate else 0)).standard_normal((D, 3)).astype(np.float32) for l in range(L)]
    offs = [deg * l / L for l in range(L)]  # deterministic offset per layer
    tables = []
    for P, off in zip(Ps, offs):
        t, p = cells(*angles(Xn, P), deg, off)
        keys = t * 1000 + p
        order = np.argsort(keys, kind="stable")
        uk, start = np.unique(keys[order], return_index=True)
        parts = np.split(order, start[1:])
        tables.append(dict(zip(uk.tolist(), parts)))
    rec, scn = [], []
    for q, tr in zip(Q, truth):
        cand = []
        for P, off, tb in zip(Ps, offs, tables):
            t, p = cells(*angles(q[None], P), deg, off)
            t, p = int(t[0]), int(p[0])
            for dt in (-1, 0, 1):
                for dp in (-1, 0, 1):
                    a = tb.get((t + dt) * 1000 + (p + dp) % nphi)
                    if a is not None:
                        cand.append(a)
        c = np.unique(np.concatenate(cand)) if cand else np.empty(0, int)
        top = c[np.argsort(-(Xn[c] @ q))[:K]] if len(c) else c
        rec.append(len(tr & set(top.tolist())) / K)
        scn.append(len(c))
    return np.mean(rec), np.mean(scn)


print(f"N={N} D={D}, probe = 3x3 cells/layer, scan = unique candidates (brute={N})")
print("deg  L  mode            recall@10  scanned")
for deg in (30, 15):
    for L in (1, 2, 4, 8):
        for rot in (False, True):
            if L == 1 and rot:
                continue
            r, s = run(L, deg, rot)
            print(f"{deg:>3} {L:>2}  {'rotate+offset' if rot else 'offset-only  '}   {r:.3f}     {s:.0f}")
