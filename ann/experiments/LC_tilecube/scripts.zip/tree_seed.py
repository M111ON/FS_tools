import numpy as np, struct, math, hashlib
np.seterr(over="ignore")
exec(open("seedsim.py").read().split("# ---- 1) real data")[0])   # fnv_rows, mix64, seed_fields, ncoll, M

p="/mnt/user-data/attachments/ff6529cf-50c6-5af9-9e9f-bff721559dca/f8b0b9b6-ann_index.f16"
raw=open(p,"rb").read(); _,_,dim,n,_=struct.unpack("<5I",raw[8:28])
Bt=np.frombuffer(raw[28:28+n*dim*2],dtype=np.uint8).reshape(n,dim*2)
V=np.frombuffer(raw[28:28+n*dim*2],dtype=np.float16).reshape(n,dim).astype(np.float32)
Vn=V/np.linalg.norm(V,axis=1,keepdims=True)
rng=np.random.default_rng(7); qi=rng.choice(n,200,replace=False)
keep=np.ones(n,bool); keep[qi]=False
X,Q,XB=Vn[keep],Vn[qi],Bt[keep]; N=len(X); K_=10
truth=[set(np.argsort(-(X@q))[:K_]) for q in Q]
H=fnv_rows(XB,salt=b"ann20k|384|f16"); SEED=seed_fields(H)[0]      # identity per row (space id mixed in)
CAP=1000
def l2(A,C): return (A**2).sum(1)[:,None]-2*A@C.T+(C**2).sum(1)[None,:]
def kfor(n_): k=math.ceil(n_/1000); return (k+3)//4*4
def lloyd(Xs,K,it=25):
    C=Xs[np.linspace(0,len(Xs)-1,K).astype(int)].copy()
    for _ in range(it):
        a=l2(Xs,C).argmin(1)
        for k in range(K):
            s=a==k
            if s.any(): C[k]=Xs[s].mean(0)
    return C
def two_means(Xs):                      # deterministic, members already in row order
    d=l2(Xs,Xs[:1])[:,0]; b=int(d.argmax()); C=np.stack([Xs[0],Xs[b]])
    for _ in range(15):
        a=l2(Xs,C).argmin(1)
        if a.min()==a.max():            # degenerate: split at median along (b-a)
            pr=Xs@(Xs[b]-Xs[0]); a=(pr>np.median(pr)).astype(int)
        for k in (0,1): C[k]=Xs[a==k].mean(0)
    return C,l2(Xs,C).argmin(1) if True else None

class Node:
    def __init__(s,path,cent): s.path=path; s.cent=cent; s.kids=None; s.rows=[]
class Tree:
    def __init__(s): s.roots=None
    def descend(s,v):
        i=int(l2(v[None],s.rootC).argmin()); nd=s.roots[i]
        while nd.kids: nd=nd.kids[int(l2(v[None],np.stack([k.cent for k in nd.kids])).argmin())]
        return nd
    def leaves(s):
        out=[];st=list(s.roots)
        while st:
            nd=st.pop()
            if nd.kids: st+=nd.kids
            else: out.append(nd)
        return sorted(out,key=lambda x:x.path)
    def add_batch(s,rows):
        rows=sorted(rows)                       # order-independent within a batch
        if s.roots is None:
            K=kfor(len(rows)); C=lloyd(X[rows],K); s.rootC=C
            s.roots=[Node(str(i),C[i]) for i in range(K)]
        for r in rows: s.descend(X[r]).rows.append(r)
        s.split_full()
    def split_full(s):
        again=True
        while again:
            again=False
            for lf in s.leaves():
                if len(lf.rows)>CAP:
                    rs=sorted(lf.rows); C,a=two_means(X[rs])
                    lf.kids=[Node(lf.path+"."+str(j),C[j]) for j in (0,1)]
                    for r,j in zip(rs,a): lf.kids[j].rows.append(r)
                    lf.rows=[]; again=True
    def addr(s):
        return {r:lf.path for lf in s.leaves() for r in lf.rows}
def digest(a): return hashlib.sha256(",".join(f"{r}:{a[r]}" for r in sorted(a)).encode()).hexdigest()[:12]
def build(schedule,shuffle=False):
    t=Tree(); prev=0; snaps=[]
    for e in schedule:
        rows=list(range(prev,e))
        if shuffle: np.random.default_rng(e).shuffle(rows)
        t.add_batch(rows); snaps.append((e,t.addr())); prev=e
    return t,snaps
def seek(t,q,b):
    lv=t.leaves(); C=np.stack([l.cent for l in lv]); o=l2(q[None],C)[0].argsort()[:b]
    return np.concatenate([np.array(lv[i].rows,int) for i in o if lv[i].rows]) if True else None
def recall(t,upto,b):
    sub=set(range(upto)); rec=[];sc=[]
    for q in Q:
        s=X[:upto]@q; tr=set(np.argsort(-s)[:K_].tolist())
        ids=seek(t,q,b); top=ids[np.argsort(-(X[ids]@q))[:K_]]
        rec.append(len(tr&set(top.tolist()))/K_); sc.append(len(ids))
    return np.mean(rec),np.mean(sc)

S4=[N//4,N//2,3*N//4,N]; S3=[N//3,2*N//3,N]
t,snaps=build(S4); fin=snaps[-1][1]
print(f"N={N}, CAP={CAP}, K0={kfor(S4[0])}, final leaves={len(t.leaves())}, max leaf={max(len(l.rows) for l in t.leaves())}, depth max={max(l.path.count('.') for l in t.leaves())}")
print("\n[1] determinism")
t2,s2=build(S4); print("rerun digest equal:",digest(fin)==digest(s2[-1][1]),digest(fin))
t3,s3=build(S4,shuffle=True); print("shuffled insert order within batches, digest equal:",digest(fin)==digest(s3[-1][1]))
t4,s4=build(S3); diff=np.mean([fin[r].split('.')[0]!=s4[-1][1][r].split('.')[0] or fin[r]!=s4[-1][1][r] for r in range(N)])
print(f"different batch schedule (3 stages vs 4): {100*diff:.1f}% of vectors end with a different address")
print("\n[2] address stability across growth (prefix test: old address is a prefix of new)")
for i in range(len(snaps)-1):
    e,a=snaps[i]; ok=np.mean([ (fin[r]==a[r]) or fin[r].startswith(a[r]+".") for r in range(e)])
    same=np.mean([fin[r]==a[r] for r in range(e)])
    print(f" stage n={e}: {100*ok:.1f}% keep their address as a prefix ({100*same:.1f}% unchanged exactly)")
# baseline: full retrain each stage, bucket id = k-means index
print(" baseline full retrain (K from n, id = centroid index):")
for i in range(len(S4)-1):
    e=S4[i]; Ca=lloyd(X[:e],kfor(e)); Cb=lloyd(X,kfor(N))
    same=np.mean(l2(X[:e],Ca).argmin(1)==l2(X[:e],Cb).argmin(1)); print(f"   n={e}: {100*same:.1f}% keep their bucket id after retrain (K {kfor(e)}->{kfor(N)})")
print("\n[3] locate by seed (db: seed->vector; allocation record: seed->home address at insert time)")
home={}; 
for e,a in snaps:                                   # record written once, at first insert
    for r,pth in a.items(): home.setdefault(SEED[r],pth)
db={}; 
for r in range(N): db.setdefault(SEED[r],r)
def node_at(t,path):
    parts=path.split("."); nd=t.roots[int(parts[0])]
    for j in parts[1:]: nd=nd.kids[int(j)]
    return nd
ok=0;steps=0
for sd,r in db.items():
    nd=node_at(t,home[sd]); 
    while nd.kids: nd=nd.kids[int(l2(X[r][None],np.stack([k.cent for k in nd.kids])).argmin())]; steps+=1
    ok+= r in nd.rows
print(f" distinct seeds {len(db)} (rows {N}; {N-len(db)} byte-identical duplicates share a seed) -> located {ok}/{len(db)}; avg extra descent steps {steps/len(db):.2f}")
print("\n[4] seek (best b leaves by centroid L2), final tree vs flat IVF retrained with same leaf count")
leafK=len(t.leaves()); Cf=lloyd(X,leafK); af=l2(X,Cf).argmin(1)
for b in (1,2,3,5):
    r1,s1=recall(t,N,b)
    rec=[];sc=[]
    for q in Q:
        tr=set(np.argsort(-(X@q))[:K_].tolist()); o=l2(q[None],Cf)[0].argsort()[:b]
        ids=np.where(np.isin(af,o))[0]; top=ids[np.argsort(-(X[ids]@q))[:K_]]
        rec.append(len(tr&set(top.tolist()))/K_); sc.append(len(ids))
    print(f" b={b}: tree recall {r1:.3f} @ {100*s1/N:.1f}% scanned | retrained flat K={leafK}: {np.mean(rec):.3f} @ {100*np.mean(sc)/N:.1f}%")
