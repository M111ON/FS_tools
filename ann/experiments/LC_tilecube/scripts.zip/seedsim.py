import numpy as np, struct, math, time
np.seterr(over="ignore")
M=np.uint64
FNV_O=M(0xcbf29ce484222325); FNV_P=M(0x100000001b3)
def fnv_rows(B, salt=None):
    """B: (n, L) uint8 -> FNV-1a 64 per row. salt: bytes mixed in first (space id)."""
    h=np.full(B.shape[0],FNV_O,dtype=np.uint64)
    if salt:
        for b in salt: h=(h^M(b))*FNV_P
    for j in range(B.shape[1]): h=(h^B[:,j].astype(np.uint64))*FNV_P
    return h
def mix64(z):
    z=z.copy(); z^=z>>M(30); z*=M(0xbf58476d1ce4e5b9); z^=z>>M(27); z*=M(0x94d049bb133111eb); z^=z>>M(31); return z
def seed_fields(h, level=0):
    m1=mix64(h); m2=mix64(h^M(0x9E3779B97F4A7C15))
    major=(((m1&M(0xFFFF))*M(24))>>M(16)).astype(np.uint64)
    cube =((((m1>>M(16))&M(0xFFFF))*M(48))>>M(16)).astype(np.uint64)
    inner=(m1>>M(32))&M(0xFFF); outer=(m1>>M(44))&M(0xFFF); chk=m2&M(0x1FFF)
    seed=(major<<M(59))|(M(level)<<M(43))|(cube<<M(37))|(inner<<M(25))|(outer<<M(13))|chk
    return seed,major,cube,inner,outer,chk
def ncoll(a):
    u=np.unique(a); return len(a)-len(u)           # rows that share a value with an earlier row

# ---- 1) real data (20k, f16 bytes) ----
p="/mnt/user-data/attachments/ff6529cf-50c6-5af9-9e9f-bff721559dca/f8b0b9b6-ann_index.f16"
raw=open(p,"rb").read(); _,_,dim,n,_=struct.unpack("<5I",raw[8:28])
B=np.frombuffer(raw[28:28+n*dim*2],dtype=np.uint8).reshape(n,dim*2)
h=fnv_rows(B); seed,major,cube,inner,outer,chk=seed_fields(h)
dup_vec=n-len({r.tobytes() for r in B})
print(f"REAL n={n}: identical vectors (byte-equal) {dup_vec} | distinct FNV64 {len(np.unique(h))} | seed collisions (rows) {ncoll(seed)}")
# determinism: re-hash
print("re-run identical:", bool((fnv_rows(B)==h).all()))
# space-id salt separates same bytes
hs=fnv_rows(B,salt=b"pplx-embed-v1-0.6b|384|f16"); print("same bytes, different space id -> same seed? ", int((seed_fields(hs)[0]==seed).sum()),"of",n)
# field uniformity (real)
def chi(x,k):
    c=np.bincount(x.astype(np.int64),minlength=k); e=len(x)/k; return ((c-e)**2/e).sum()/(k-1)
print("field chi2/df (≈1 is uniform): major",round(chi(major,24),2),"cube",round(chi(cube,48),2),"inner(12b->64 bins)",round(chi(inner&M(63),64),2),"chk",round(chi(chk&M(63),64),2))

# ---- 2) synthetic distinct inputs through the same FNV+Mix64 ----
def synth(N, off=0):
    ids=(np.arange(N,dtype=np.uint64)+M(off))
    B=np.empty((N,8),dtype=np.uint8)
    for j in range(8): B[:,j]=((ids>>M(8*j))&M(0xFF)).astype(np.uint8)
    return fnv_rows(B)
print("\nSYNTH distinct inputs: observed colliding rows vs model  N^2/2 / 2^47.2 (seed fields) and /2^64 (stored full hash)")
eff=24*48*2**12*2**12*2**13
print("N          trials  seed-obs(avg)  model     |  h64-obs  model")
for N,tr in ((1_000_000,6),(10_000_000,6)):
    so=0; ho=0
    for t in range(tr):
        hh=synth(N, off=t*N*3); s=seed_fields(hh)[0]&~(M(0xFFFF)<<M(43))  # ignore level
        so+=ncoll(s); ho+=ncoll(hh)
    print(f"{N:<10} {tr:<7} {so/tr:<14.3f} {N*N/2/eff:<9.3f} |  {ho/tr:<8.3f} {N*N/2/2**64:.1e}")
# model validation at a truncated key (30 bits) where collisions are plentiful
N=1_000_000; hh=synth(N); k=hh&M((1<<30)-1)
print(f"validation, 30-bit key @1M: observed {ncoll(k)} vs model {N*N/2/2**30:.0f}")
