"""lettercube.py - reference implementation of the 2x2x2 letter arrangement (Win's design, as understood 2026-11-02).

Frame / pool
  52 letters = 26 pairs (upper/lower). entry pair (position 1), exit pair (position 6, the forced leftover),
  24 minor pairs on the 8-cube block.
Block (2x2x2 = 8 cubes C1..C8 = coordinates (x,y,z) in {0,1}^3, C1=(0,0,0) C2=(1,0,0) C3=(0,1,0) C4=(1,1,0) C5.. = z=1)
  12 Q3 edges p1..p12 (cube pairs). Every edge carries TWO letter pairs:
    inner  : the interface square between the two cubes (twin faces B on one cube, b on the other)
    outer  : the pair of outside squares on OPPOSITE sides of the big cube (same position) -> axes (1,6),(2,4),(3,5)
  => 12 inner + 12 outer = 24 minor letters, 48 faces, every letter exactly twice (once upper, once lower).
Arrangement code = rank of a permutation of the 26 pairs over [entry, inner p1..p12, outer p1..p12, exit] (26!)
                   x 24 orientation bits (which cube of the pair holds the uppercase)  ->  26! * 2^24 = 6.8e33 (2^112.4)
"""
import itertools, random
from math import factorial as f

CUBE = {f"C{i+1}": (x, y, z) for i, (z, y, x) in enumerate(itertools.product((0, 1), repeat=3))}
EDGE = {1: ("C1", "C2"), 2: ("C1", "C3"), 3: ("C2", "C4"), 4: ("C3", "C4"), 5: ("C5", "C6"), 6: ("C5", "C7"),
        7: ("C6", "C8"), 8: ("C7", "C8"), 9: ("C1", "C5"), 10: ("C2", "C6"), 11: ("C3", "C7"), 12: ("C4", "C8")}
CYCLE = [("C1", "C2", 1), ("C2", "C4", 3), ("C4", "C3", 4), ("C3", "C7", 11), ("C7", "C8", 8), ("C8", "C6", 7), ("C6", "C5", 5), ("C5", "C1", 9)]
SPACE = f(26) * 2 ** 24

def axis_of(k):
    a, b = (CUBE[c] for c in EDGE[k]); d = [i for i in range(3) if a[i] != b[i]]; assert len(d) == 1; return d[0]
for k in EDGE: axis_of(k)

def unrank(r, n=26):
    it = list(range(n)); out = []
    for i in range(n, 0, -1):
        q, r = divmod(r, f(i - 1)); out.append(it.pop(q))
    return out
def rank(p):
    it = list(range(len(p))); r = 0
    for i, x in enumerate(p):
        k = it.index(x); r += k * f(len(p) - 1 - i); it.pop(k)
    return r

def arrange(code):
    """code in [0, SPACE) -> dict with entry/exit pair, inner[k], outer[k] letters and the 48-face table."""
    r, o = divmod(code, 2 ** 24); p = unrank(r)
    inner = {k: p[k] for k in range(1, 13)}; outer = {k: p[12 + k] for k in range(1, 13)}
    faces = {}
    for bit, (kind, tbl) in enumerate((("i", inner), ("o", outer))):
        for k in range(1, 13):
            X, Y = EDGE[k]; up = (o >> (bit * 12 + k - 1)) & 1       # 0: uppercase on X, 1: uppercase on Y
            faces[(X, k, kind)] = (tbl[k], 1 if up == 0 else 0)
            faces[(Y, k, kind)] = (tbl[k], 0 if up == 0 else 1)
    return dict(entry=p[0], exit=p[25], inner=inner, outer=outer, faces=faces, code=code)

def code_of(a):
    p = [a["entry"]] + [a["inner"][k] for k in range(1, 13)] + [a["outer"][k] for k in range(1, 13)] + [a["exit"]]
    o = 0
    for bit, kind in enumerate(("i", "o")):
        for k in range(1, 13):
            X, Y = EDGE[k]; up_on_Y = a["faces"][(Y, k, kind)][1]; o |= up_on_Y << (bit * 12 + k - 1)
    return rank(p) * 2 ** 24 + o

def name(letter, case): return chr(ord("A") + letter) if case else chr(ord("a") + letter)

def validate(a):
    F = a["faces"]; assert len(F) == 48
    allp = [a["entry"], a["exit"]] + [a["inner"][k] for k in a["inner"]] + [a["outer"][k] for k in a["outer"]]
    assert sorted(allp) == list(range(26))                                   # 26 pairs, each used once; exit = forced leftover
    by = {}
    for face, (L, c) in F.items(): by.setdefault(L, []).append((face, c))
    assert len(by) == 24
    for L, ((f1, c1), (f2, c2)) in by.items():
        assert c1 != c2                                                      # B on one face, b on the other
        assert f1[1] == f2[1] and f1[2] == f2[2] and f1[0] != f2[0]          # same edge, same kind, different cubes
        d = sum(x != y for x, y in zip(CUBE[f1[0]], CUBE[f2[0]])); assert d == 1   # cubes are Q3 neighbours
    for c in CUBE:                                                           # 6 distinct letters on every cube
        ls = [F[(c, k, kind)][0] for k in EDGE if c in EDGE[k] for kind in "io"]; assert len(ls) == 6 and len(set(ls)) == 6
    return True

def step(a, cube, letter, case):
    """leave `cube` through the face carrying (letter, case); return (next cube, arrival face letter/case)."""
    F = a["faces"]; here = [fc for fc, v in F.items() if fc[0] == cube and v == (letter, case)]; assert len(here) == 1
    _, k, kind = here[0]; X, Y = EDGE[k]; nxt = Y if cube == X else X
    return nxt, F[(nxt, k, kind)]

def _parts(a):
    slots = [a["inner"][k] for k in range(1, 13)] + [a["outer"][k] for k in range(1, 13)]   # 24 interior slots
    o = code_of(a) % 2 ** 24
    return a["entry"], slots, a["exit"], o
def _build(entry, slots, exit_, o):
    return arrange(rank([entry] + slots + [exit_]) * 2 ** 24 + o)

def next_level(a, c):
    """Level l -> level l+1 (forced handoff). entry' = old exit. c in 0..24 picks the new exit among the 25 other pairs:
       c == 24 -> new exit = old entry (interior untouched); c < 24 -> interior slot c becomes the exit and the old entry
       takes its slot. Exactly <=1 interior slot changes per level; pool is per level (always a full permutation of 26)."""
    entry, slots, exit_, o = _parts(a)
    if c == 24: return _build(exit_, slots, entry, o)
    s2 = list(slots); new_exit = s2[c]; s2[c] = entry
    return _build(exit_, s2, new_exit, o)

def prev_level(b, c):
    """exact inverse of next_level given the same c (c is re-derivable from seed x level)."""
    entry, slots, exit_, o = _parts(b)               # entry == old exit
    if c == 24: return _build(exit_, slots, entry, o)    # old entry == b.exit
    s2 = list(slots); old_entry = s2[c]; s2[c] = exit_
    return _build(old_entry, s2, entry, o)

def head_build(outer_head, rng):
    """'check at the head': 12 outer letters must be distinct; the inner 12 are then the remaining 12 in any order,
    so uniqueness of all 24 minor letters is guaranteed without checking the inner part."""
    assert len(set(outer_head)) == 12
    rest = [x for x in range(26) if x not in outer_head]; rng.shuffle(rest)
    entry, exit_, inner = rest[0], rest[1], rest[2:14]; assert len(rest) == 14
    p = [entry] + inner + list(outer_head) + [exit_]
    return arrange(rank(p) * 2 ** 24 + rng.randrange(2 ** 24))

if __name__ == "__main__":
    rng = random.Random(5); N = 20000
    ok = rt = 0
    for _ in range(N):
        a = arrange(rng.randrange(SPACE)); ok += validate(a); rt += code_of(a) == a["code"]
    print(f"random arrangements validated: {ok}/{N} | rank<->arrangement round-trip: {rt}/{N}")
    h = 0
    for _ in range(N):
        outer = rng.sample(range(26), 12); a = head_build(outer, rng); h += validate(a)
    print(f"built from a distinct outer head only -> inner automatically unique: {h}/{N} valid")
    cyc = 0; spread = set()
    for _ in range(N):
        a = arrange(rng.randrange(SPACE)); cube = "C1"
        for X, Y, k in CYCLE:
            L, c = a["faces"][(X, k, "i")]; cube, _ = step(a, cube, L, c); assert cube == Y
        cyc += cube == "C1"
    print(f"Hamiltonian cycle walked by inner letters returns to C1: {cyc}/{N}")
    a = arrange(rng.randrange(SPACE)); nb = {}
    for c in CUBE:
        dests = []
        for k in EDGE:
            if c in EDGE[k]:
                for kind in "io":
                    L, cs = a["faces"][(c, k, kind)]; dests.append(step(a, c, L, cs)[0])
        nb[c] = sorted(dests)
    print("each cube: 6 faces -> destinations (3 neighbours x 2 faces):", nb["C1"], "| all cubes have 3 distinct neighbours twice:",
          all(len(set(v)) == 3 and all(v.count(x) == 2 for x in set(v)) for v in nb.values()))
    print(f"space size 26!*2^24 = {SPACE:.3e}")
