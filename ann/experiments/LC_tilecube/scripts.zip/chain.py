import numpy as np, struct, math, time
np.seterr(over="ignore")
src=open("seedsim.py").read()
exec(src.split("# ---- 1) real data")[0])                 # M, fnv_rows, mix64, seed_fields
exec("def synth"+src.split("def synth")[1].split("print(")[0])
GOLD=M(0x9E3779B97F4A7C15)
def draw(seed,L):                                         # counter-based: any level in O(1)
    z=mix64(seed^(GOLD*M(L+1))); return ((z>>M(32))*M(48))>>M(32)       # 0..47 = 24 minor pairs x 2 orientation
def sym(seed,L,v1):
    if (not v1) or L%2==0: return draw(seed,L)
    f=draw(seed,L-1); inner=(f>>M(1))<M(12)               # pair index <12 = "fixed/inner" -> twin forces next level
    return np.where(inner,f^M(1),draw(seed,L))
def walk(seed,D,v1):                                      # step-by-step state machine (independent code path)
    out=[]
    for L in range(D):
        if v1 and L%2==1:
            prev=out[L-1]; s=np.where((prev>>M(1))<M(12),prev^M(1),draw(seed,L))
        else: s=draw(seed,L)
        out.append(s)
    return out
def depth_profile(seeds,v1,maxd=10,show=(2,3,4,5,6,8)):
    P=np.zeros(len(seeds),dtype=np.uint64); res={}; first=None
    for d in range(maxd):
        P=mix64(P*M(1000003)+sym(seeds,d,v1)+M(1))
        if d+1 in show or first is None:
            _,inv,cnt=np.unique(P,return_inverse=True,return_counts=True); dup=int((cnt[inv]>1).sum())
            if d+1 in show: res[d+1]=dup
            if dup==0 and first is None: first=d+1
        if first is not None and d+1>=max(show): break
    return res,first

print("[1] random-access jump == step-by-step walk")
sd=seed_fields(synth(200_000))[0]&~(M(0xFFFF)<<M(43))
for v1 in (False,True):
    W=walk(sd,40,v1); bad=sum(int((sym(sd,L,v1)!=W[L]).sum()) for L in range(40))
    print(f"  {'V1 twin-forced' if v1 else 'V0 free      '}: mismatches over 200k seeds x 40 levels = {bad}")
print("\n[2] letter balance at level 0 (48 symbols), real 20k seeds")
p="/mnt/user-data/attachments/ff6529cf-50c6-5af9-9e9f-bff721559dca/f8b0b9b6-ann_index.f16"
raw=open(p,"rb").read(); _,_,dim,n,_=struct.unpack("<5I",raw[8:28])
B=np.frombuffer(raw[28:28+n*dim*2],dtype=np.uint8).reshape(n,dim*2)
Hh=fnv_rows(B,salt=b"ann20k|384|f16"); real=np.unique(seed_fields(Hh)[0]&~(M(0xFFFF)<<M(43)))
c=np.bincount(draw(real,0).astype(int),minlength=48); e=len(real)/48
print(f"  distinct seeds {len(real)}; per-symbol count min {c.min()} max {c.max()} (uniform {e:.0f}); chi2/df {((c-e)**2/e).sum()/47:.2f}")
inner=c.reshape(24,2)[:12].sum()/c.sum(); print(f"  share of fixed(inner) letters {100*inner:.1f}% / free(outer) {100*(1-inner):.1f}%")
print("\n[3] depth needed so every distinct seed has a unique chain prefix (rows NOT unique at depth d)")
th0=lambda N:math.ceil(math.log(N*N/2)/math.log(48)); th1=lambda N:2*math.ceil(math.log(N*N/2)/math.log(1176))
for name,N,seeds in (("real 20k",len(real),real),("synth 1M",None,None),("synth 10M",None,None)):
    if seeds is None:
        N=1_000_000 if "1M" in name else 10_000_000
        seeds=np.unique(seed_fields(synth(N,off=777))[0]&~(M(0xFFFF)<<M(43)))
    N=len(seeds)
    for v1 in (False,True):
        t=time.time(); res,first=depth_profile(seeds,v1)
        th=th1(N) if v1 else th0(N)
        print(f"  {name:<9} N={N:>8} {'V1' if v1 else 'V0'}: "+" ".join(f"d{d}:{res[d]}" for d in sorted(res))+f" | first fully unique depth {first} (theory ~{th})  {time.time()-t:.0f}s")
