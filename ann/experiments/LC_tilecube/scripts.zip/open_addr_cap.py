import numpy as np, struct, math

p = "/mnt/user-data/attachments/ff6529cf-50c6-5af9-9e9f-bff721559dca/f8b0b9b6-ann_index.f16"
raw = open(p, "rb").read()
_, _, dim, n, _ = struct.unpack("<5I", raw[8:28])
V = np.frombuffer(raw[28:28 + n * dim * 2], dtype=np.float16).reshape(n, dim).astype(np.float32)
Vn = V / np.linalg.norm(V, axis=1, keepdims=True)

rng = np.random.default_rng(7)
qi = rng.choice(n, 200, replace=False)
mask = np.ones(n, bool); mask[qi] = False
X, Q = Vn[mask], Vn[qi]
K = 10
truth = [set(np.argsort(-(X @ q))[:K]) for q in Q]
N = len(X)
mu = X.mean(0)
w, E = np.linalg.eigh(np.cov((X - mu).T))
P = E[:, ::-1][:, :3].astype(np.float32)  # frozen PCA top-3


def home(V_, deg):
    U = (V_ - mu) @ P
    U /= np.linalg.norm(U, axis=1, keepdims=True) + 1e-9
    th = np.degrees(np.arccos(np.clip(U[:, 2], -1, 1)))
    ph = np.degrees(np.arctan2(U[:, 1], U[:, 0])) % 360
    return np.minimum((th // deg).astype(int), int(180 / deg) - 1), (ph // deg).astype(int) % int(360 / deg)



def run(deg, cap):
    nt, nph = int(180 / deg), int(360 / deg)
    ncell = nt * nph
    print(f"\n=== grid {deg} deg: {ncell} houses x capacity {cap} = {ncell*cap} slots, N={N}, fill={100*N/(ncell*cap):.0f}% ===")
    ht, hp = home(X, deg); qt, qp = home(Q, deg)
    R = 60
    offs = sorted([(dt, dp) for dt in range(-R, R + 1) for dp in range(-R, R + 1)],
                  key=lambda o: (max(abs(o[0]), abs(o[1])), o[0] ** 2 + o[1] ** 2, o[0], o[1]))
    def cell_at(t, p_, k):
        dt, dp = offs[k]; tt = t + dt
        if tt < 0 or tt >= nt: return None
        return tt * nph + (p_ + dp) % nph
    slots = [[] for _ in range(ncell)]; ks = np.zeros(N, int); rs = np.zeros(N, int)
    for i in range(N):
        k = 0
        while True:
            c = cell_at(ht[i], hp[i], k)
            if c is not None and len(slots[c]) < cap:
                slots[c].append(i); ks[i] = k; rs[i] = max(abs(offs[k][0]), abs(offs[k][1])); break
            k += 1
    print(f"displaced {100*(ks>0).mean():.1f}% | ring mean {rs.mean():.2f} p95 {np.percentile(rs,95):.0f} max {rs.max()} | empty houses {100*np.mean([len(s)==0 for s in slots]):.0f}% | max in a house {max(len(s) for s in slots)}")
    for M in (1, 9, 25, 49):
        rec, found = [], []
        for q, tr, t, p_ in zip(Q, truth, qt, qp):
            ids = []
            for k in range(M):
                c = cell_at(t, p_, k)
                if c is not None: ids += slots[c]
            ids = np.array(ids, int)
            top = ids[np.argsort(-(X[ids] @ q))[:K]] if len(ids) else ids
            rec.append(len(tr & set(top.tolist())) / K); found.append(len(ids))
        print(f"   seek {M:>2} houses -> recall@10 {np.mean(rec):.3f}  (scanned {np.mean(found):.0f} = {100*np.mean(found)/N:.1f}%)")

for deg, cap in ((3, 4), (6, 16), (10, 40)):
    run(deg, cap)
