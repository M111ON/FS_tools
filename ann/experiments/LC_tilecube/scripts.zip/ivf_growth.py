import numpy as np, struct, math
p="/mnt/user-data/attachments/ff6529cf-50c6-5af9-9e9f-bff721559dca/f8b0b9b6-ann_index.f16"
raw=open(p,"rb").read(); _,_,dim,n,_=struct.unpack("<5I",raw[8:28])
V=np.frombuffer(raw[28:28+n*dim*2],dtype=np.float16).reshape(n,dim).astype(np.float32)
Vn=V/np.linalg.norm(V,axis=1,keepdims=True)
rng=np.random.default_rng(7); qi=rng.choice(n,200,replace=False)
m=np.ones(n,bool); m[qi]=False; X,Q=Vn[m],Vn[qi]; N=len(X); K_=10
truth=[set(np.argsort(-(X@q))[:K_])for q in Q]

def l2(A,C): return (A**2).sum(1)[:,None]-2*A@C.T+(C**2).sum(1)[None,:]
def lloyd(Xs,K,it=25):
    C=Xs[np.linspace(0,len(Xs)-1,K).astype(int)].copy()
    for _ in range(it):
        a=l2(Xs,C).argmin(1)
        for k in range(K):
            s=a==k
            if s.any(): C[k]=Xs[s].mean(0)
    return C,l2(Xs,C).argmin(1)
def kfor(n_): k=math.ceil(n_/1000); return (k+3)//4*4

def evaluate(name,C,assign):
    sizes=np.bincount(assign,minlength=len(C))
    members=[np.where(assign==k)[0] for k in range(len(C))]
    order=l2(Q,C).argsort(1)
    out=[]
    for b in (1,2,3,5):
        rec,sc=[],[]
        for q,tr,o in zip(Q,truth,order):
            ids=np.concatenate([members[k] for k in o[:b]])
            top=ids[np.argsort(-(X[ids]@q))[:K_]]
            rec.append(len(tr&set(top.tolist()))/K_); sc.append(len(ids))
        out.append(f"b={b}: {np.mean(rec):.3f}@{100*np.mean(sc)/N:.0f}%")
    print(f"{name:<34} K={len(C):<3} bucket max/mean {sizes.max()}/{sizes.mean():.0f} | "+"  ".join(out))

# A: static, their rule K=ceil(n/1000) round up to x4
K=kfor(N); C,a=lloyd(X,K); evaluate("A static full train (their rule)",C,a)

# growth: train on first half, then add the rest
n0=N//2; K0=kfor(n0)
C0,a0=lloyd(X[:n0],K0); print(f"\nstage 1: n={n0}, K={K0}")
evaluate("stage-1 index",C0,l2(X[:n0],C0).argmin(1)) if False else None
# (b) incremental append: reuse anchors, new rows routed to old anchors
ab=np.concatenate([a0,l2(X[n0:],C0).argmin(1)]); evaluate("B append, anchors frozen",C0,ab)
# (a) full retrain with new K
Cf,af=lloyd(X,kfor(N)); chg=(af[:n0]!=a0).mean()
evaluate("C full retrain (K grows)",Cf,af)
print(f"   -> {100*chg:.0f}% of the first {n0} vectors get a different bucket id after full retrain (K {K0}->{kfor(N)})")
# (c) split only buckets over 1000, keep parent id as prefix
leaves=[];cents=[];parent=[]
for k in range(K0):
    idx=np.where(ab==k)[0]
    stack=[(idx,C0[k],str(k))]
    while stack:
        ix,c,lab=stack.pop()
        if len(ix)>1000:
            Cs,asg=lloyd(X[ix],2,15)
            for j in (0,1): stack.append((ix[asg==j],Cs[j],lab+"."+str(j)))
        else: leaves.append(ix);cents.append(c);parent.append(lab)
Cs=np.array(cents); asg=np.empty(N,int)
for li,ix in enumerate(leaves): asg[ix]=li
evaluate("D split full buckets (parent prefix)",Cs,asg)
roots=np.array([int(l.split(".")[0]) for l in parent])
print(f"   -> leaf count {len(leaves)}; root prefix of every old vector unchanged: {100*(roots[asg[:n0]]==a0).mean():.0f}%")
