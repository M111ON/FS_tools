import numpy as np, struct

p = "/mnt/user-data/attachments/ff6529cf-50c6-5af9-9e9f-bff721559dca/f8b0b9b6-ann_index.f16"
raw = open(p, "rb").read()
magic = raw[:8]
ver, flag, dim, n, zero = struct.unpack("<5I", raw[8:28])
print("magic", magic, "ver", ver, flag, "dim", dim, "rows", n, zero)
V = np.frombuffer(raw[28:28 + n * dim * 2], dtype=np.float16).reshape(n, dim).astype(np.float32)
nr = np.linalg.norm(V, axis=1)
print("norm min/mean/max", nr.min(), nr.mean(), nr.max(), " zero rows", int((nr == 0).sum()))
Vn = V / np.maximum(nr[:, None], 1e-9)
mu = Vn.mean(0)
print("norm of mean direction", np.linalg.norm(mu))

rng = np.random.default_rng(7)
qi = rng.choice(n, 200, replace=False)
mask = np.ones(n, bool); mask[qi] = False
base_ids = np.where(mask)[0]
X, Q = Vn[base_ids], Vn[qi]
K = 10
truth = [set(np.argsort(-(X @ q))[:K]) for q in Q]
nb = len(X)
mu = X.mean(0)
C = np.cov((X - mu).T)
w, E = np.linalg.eigh(C)
E = E[:, ::-1]  # PCA components, strongest first
print("top-9 PCA var share", np.round(w[::-1][:9] / w.sum(), 3), " top3 sum", round(float(w[::-1][:3].sum() / w.sum()), 3))


def angles(V_, P):
    U = (V_ - mu) @ P
    U /= np.linalg.norm(U, axis=1, keepdims=True) + 1e-9
    th = np.degrees(np.arccos(np.clip(U[:, 2], -1, 1)))
    ph = np.degrees(np.arctan2(U[:, 1], U[:, 0])) % 360
    return th, ph


def cells(th, ph, deg, off):
    return ((th + off) // deg).astype(int), (((ph + off) % 360) // deg).astype(int)


def make_P(kind, L):
    if kind == "random-1proj":
        return [np.random.default_rng(100).standard_normal((dim, 3)).astype(np.float32)] * L
    if kind == "random-rot":
        return [np.random.default_rng(100 + l).standard_normal((dim, 3)).astype(np.float32) for l in range(L)]
    if kind == "pca-1proj":
        return [E[:, :3].astype(np.float32)] * L
    if kind == "pca-triplets":
        return [E[:, 3 * l:3 * l + 3].astype(np.float32) for l in range(L)]


def run(kind, L, deg):
    Ps = make_P(kind, L)
    offs = [deg * l / L for l in range(L)]
    nphi = int(np.ceil(360 / deg))
    tables = []
    for P, off in zip(Ps, offs):
        t, ph = cells(*angles(X, P), deg, off)
        keys = t * 1000 + ph
        order = np.argsort(keys, kind="stable")
        uk, st = np.unique(keys[order], return_index=True)
        tables.append(dict(zip(uk.tolist(), np.split(order, st[1:]))))
    rec, scn = [], []
    for q, tr in zip(Q, truth):
        cand = []
        for P, off, tb in zip(Ps, offs, tables):
            t, ph = cells(*angles(q[None], P), deg, off)
            t, ph = int(t[0]), int(ph[0])
            for dt in (-1, 0, 1):
                for dp in (-1, 0, 1):
                    a = tb.get((t + dt) * 1000 + (ph + dp) % nphi)
                    if a is not None:
                        cand.append(a)
        c = np.unique(np.concatenate(cand)) if cand else np.empty(0, int)
        top = c[np.argsort(-(X[c] @ q))[:K]] if len(c) else c
        rec.append(len(tr & set(top.tolist())) / K); scn.append(len(c))
    return np.mean(rec), np.mean(scn)


print(f"\nREAL data N={nb} D={dim}, 3x3 probe/layer, brute={nb}")
print("kind           deg  L  recall@10  scanned(%)")
for deg in (30, 15):
    for kind, Ls in (("random-1proj", (1, 4)), ("pca-1proj", (1, 4)), ("random-rot", (4, 8)), ("pca-triplets", (4, 8))):
        for L in Ls:
            r, s = run(kind, L, deg)
            print(f"{kind:<14} {deg:>3} {L:>2}   {r:.3f}     {s:>6.0f} ({100*s/nb:.1f}%)")
