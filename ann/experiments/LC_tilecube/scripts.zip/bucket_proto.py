"""Mini vector bucket prototype: bucket + store + pluggable router.
Router = anything with address(vec)->key and probes(vec)->[keys]. Your letter_cube route can replace SphereRouter.
"""
import numpy as np, time


class Bucket:
    """Holds normalized vectors; search = dot product inside the bucket."""
    def __init__(self, dim, cap=16):
        self.vecs = np.empty((cap, dim), np.float32)
        self.ids = np.empty(cap, np.int64)
        self.n = 0

    def add(self, i, v):
        if self.n == len(self.ids):  # grow x2
            self.vecs = np.resize(self.vecs, (self.n * 2, self.vecs.shape[1]))
            self.ids = np.resize(self.ids, self.n * 2)
        self.vecs[self.n] = v
        self.ids[self.n] = i
        self.n += 1

    def search(self, q):
        if self.n == 0:
            return np.empty(0, np.int64), np.empty(0, np.float32)
        return self.ids[:self.n], self.vecs[:self.n] @ q


class BucketStore:
    def __init__(self, dim, router, promote_at=None):
        self.dim, self.router, self.promote_at = dim, router, promote_at
        self.buckets = {}  # route key -> Bucket
        self.to_promote = set()  # hook: keys whose size passed threshold

    def insert(self, i, v):
        k = self.router.address(v)
        b = self.buckets.get(k)
        if b is None:
            b = self.buckets[k] = Bucket(self.dim)
        b.add(i, v)
        if self.promote_at and b.n == self.promote_at:
            self.to_promote.add(k)

    def query(self, q, k=10, probe=True):
        keys = self.router.probes(q) if probe else [self.router.address(q)]
        ids, sc, scanned = [], [], 0
        for key in keys:
            b = self.buckets.get(key)
            if b is None:
                continue
            i, s = b.search(q)
            ids.append(i); sc.append(s); scanned += b.n
        if not ids:
            return np.empty(0, np.int64), 0
        ids, sc = np.concatenate(ids), np.concatenate(sc)
        top = np.argsort(-sc)[:k]
        return ids[top], scanned


class SphereRouter:
    """Fixed projection d->3, unit sphere, 2 angles at `deg` resolution.
    probes = own cell + 8 neighbours (phi wraps)."""
    def __init__(self, dim, deg=1, seed=0):
        rng = np.random.default_rng(seed)
        self.P = rng.standard_normal((dim, 3)).astype(np.float32)
        self.deg = deg
        self.nt, self.np_ = int(np.ceil(180 / deg)), int(np.ceil(360 / deg))

    def address(self, v):
        u = v @ self.P
        u = u / (np.linalg.norm(u) + 1e-9)
        t = np.degrees(np.arccos(np.clip(u[2], -1, 1)))
        p = np.degrees(np.arctan2(u[1], u[0])) % 360
        return (min(int(t // self.deg), self.nt - 1), int(p // self.deg) % self.np_)

    def probes(self, v):
        t, p = self.address(v)
        out = []
        for dt in (-1, 0, 1):
            for dp in (-1, 0, 1):
                tt = t + dt
                if 0 <= tt < self.nt:
                    out.append((tt, (p + dp) % self.np_))
        return out


def make_data(n, dim, clusters=50, seed=1):
    rng = np.random.default_rng(seed)
    c = rng.standard_normal((clusters, dim))
    x = c[rng.integers(0, clusters, n)] + 0.5 * rng.standard_normal((n, dim))
    x /= np.linalg.norm(x, axis=1, keepdims=True)
    return x.astype(np.float32)


if __name__ == "__main__":
    N, D, NQ, K = 20000, 128, 200, 10
    X = make_data(N, D)
    rng = np.random.default_rng(7)
    Q = X[rng.choice(N, NQ, replace=False)] + 0.1 * rng.standard_normal((NQ, D)).astype(np.float32)
    Q /= np.linalg.norm(Q, axis=1, keepdims=True)
    truth = [set(np.argsort(-(X @ q))[:K]) for q in Q]

    print(f"N={N} dim={D}  (brute force scans {N})")
    print("deg  probe  buckets  empty%  p99  max   recall@10  scanned(avg)")
    for deg in (30, 10, 5, 2):
        for probe in (False, True):
            st = BucketStore(D, SphereRouter(D, deg))
            for i, v in enumerate(X):
                st.insert(i, v)
            sizes = np.array([b.n for b in st.buckets.values()])
            total = st.router.nt * st.router.np_
            rec, scn = [], []
            for q, tr in zip(Q, truth):
                ids, s = st.query(q, K, probe)
                rec.append(len(tr & set(ids.tolist())) / K); scn.append(s)
            print(f"{deg:>3}  {str(probe):5}  {total:>6}  {100*(1-len(sizes)/total):5.1f}  "
                  f"{int(np.percentile(sizes,99)):>4} {sizes.max():>5}   {np.mean(rec):.3f}      {np.mean(scn):.0f}")
