Scripts (python3, numpy; polyhedra.py needs scipy). All real-data scripts read the ann_20k f16 file via variable p=... ; edit that path.
seedsim.py     FNV-1a+Mix64 seed layout, collisions, uniformity (chain.py/tree_seed.py exec its top half - keep in same dir)
tree_seed.py   prefix-stable tree (split full buckets with 2-means) + seed locate, float
tree_int.py    same tree, integer-only; bit-exact test
chain.py       counter-based random-access chain, depth vs choices-per-step
ivf_growth.py  IVF growth strategies (retrain / frozen append / split full buckets)
bucket_proto.py, multilayer.py, real_bench.py, open_addr.py, open_addr_cap.py  early projection/open-addressing experiments
polyhedra.py   truncated octahedron / small / great rhombicuboctahedron face shares
lettercube.py  2x2x2 letter arrangement: rank<->arrangement, validator, step, head_build, next_level/prev_level (python3 lettercube.py runs self-tests)
