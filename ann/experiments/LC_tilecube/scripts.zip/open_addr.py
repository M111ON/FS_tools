import numpy as np, struct, math

p = "/mnt/user-data/attachments/ff6529cf-50c6-5af9-9e9f-bff721559dca/f8b0b9b6-ann_index.f16"
raw = open(p, "rb").read()
_, _, dim, n, _ = struct.unpack("<5I", raw[8:28])
V = np.frombuffer(raw[28:28 + n * dim * 2], dtype=np.float16).reshape(n, dim).astype(np.float32)
Vn = V / np.linalg.norm(V, axis=1, keepdims=True)

rng = np.random.default_rng(7)
qi = rng.choice(n, 200, replace=False)
mask = np.ones(n, bool); mask[qi] = False
X, Q = Vn[mask], Vn[qi]
K = 10
truth = [set(np.argsort(-(X @ q))[:K]) for q in Q]
N = len(X)
mu = X.mean(0)
w, E = np.linalg.eigh(np.cov((X - mu).T))
P = E[:, ::-1][:, :3].astype(np.float32)  # frozen PCA top-3


def home(V_, deg):
    U = (V_ - mu) @ P
    U /= np.linalg.norm(U, axis=1, keepdims=True) + 1e-9
    th = np.degrees(np.arccos(np.clip(U[:, 2], -1, 1)))
    ph = np.degrees(np.arctan2(U[:, 1], U[:, 0])) % 360
    return np.minimum((th // deg).astype(int), int(180 / deg) - 1), (ph // deg).astype(int) % int(360 / deg)


def run(deg):
    nt, nph = int(180 / deg), int(360 / deg)
    ncell = nt * nph
    print(f"\n=== grid {deg} deg: {ncell} houses (1 occupant each), N={N}, fill={100*N/ncell:.0f}% ===")
    ht, hp = home(X, deg)
    qt, qp = home(Q, deg)

    R = 90
    offs = sorted([(dt, dp) for dt in range(-R, R + 1) for dp in range(-R, R + 1)],
                  key=lambda o: (max(abs(o[0]), abs(o[1])), o[0] ** 2 + o[1] ** 2, o[0], o[1]))  # BFS rings, deterministic tie-break
    ring = lambda o: max(abs(o[0]), abs(o[1]))

    def cell_at(t, p_, k, mode):
        if mode == "geo":
            dt, dp = offs[k]
            tt = t + dt
            if tt < 0 or tt >= nt: return None
            return tt * nph + (p_ + dp) % nph
        return (t * nph + p_ + 37 * k) % ncell  # fixed-stride ring (linear probing)

    def place(order, mode):
        occ = -np.ones(ncell, int); ks = np.zeros(N, int)
        for i in order:
            k = 0
            while True:
                c = cell_at(ht[i], hp[i], k, mode)
                if c is not None and occ[c] < 0:
                    occ[c] = i; ks[i] = k; break
                k += 1
                if mode == "geo" and k >= len(offs): raise RuntimeError("probe overflow")
        return occ, ks

    for mode in ("geo", "stride"):
        o1 = np.arange(N); o2 = np.random.default_rng(3).permutation(N)
        occ, ks = place(o1, mode)
        occ2, ks2 = place(o2, mode)
        house1 = np.empty(N, int); house2 = np.empty(N, int)
        house1[occ[occ >= 0]] = np.where(occ >= 0)[0]; house2[occ2[occ2 >= 0]] = np.where(occ2 >= 0)[0]
        disp = ks > 0
        rr = np.array([ring(offs[k]) for k in ks]) if mode == "geo" else ks
        print(f"[{mode}] displaced {100*disp.mean():.1f}% | offset idx mean {ks.mean():.1f} p95 {np.percentile(ks,95):.0f} max {ks.max()}"
              + (f" | ring mean {rr.mean():.2f} p95 {np.percentile(rr,95):.0f} max {rr.max()}" if mode == "geo" else "")
              + f" | order-dependence: {100*(house1!=house2).mean():.1f}% of vectors land in a different house under another insert order")
        for M in (1, 9, 25, 49, 81):
            rec, found = [], []
            for q, tr, t, p_ in zip(Q, truth, qt, qp):
                ids = []
                for k in range(M):
                    c = cell_at(t, p_, k, mode)
                    if c is not None and occ[c] >= 0: ids.append(occ[c])
                ids = np.array(ids, int)
                top = ids[np.argsort(-(X[ids] @ q))[:K]] if len(ids) else ids
                rec.append(len(tr & set(top.tolist())) / K); found.append(len(ids))
            print(f"   seek budget {M:>2} houses -> recall@10 {np.mean(rec):.3f}  (vectors scanned {np.mean(found):.1f})")


for deg in (1.5,):
    run(deg)
