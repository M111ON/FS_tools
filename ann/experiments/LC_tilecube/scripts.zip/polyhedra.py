# face counts + solid-angle share per face for the 3 candidate shapes (needs numpy, scipy)
import numpy as np, itertools, math
from scipy.spatial import ConvexHull
r2=math.sqrt(2)
def ps(base):
    s=set()
    for p in set(itertools.permutations(base)):
        for sg in itertools.product((1,-1),repeat=3): s.add(tuple(round(a*b,9) for a,b in zip(p,sg)))
    return np.array(sorted(s))
for name,P in {"truncated octahedron":ps((0,1,2)),"small rhombicuboctahedron":ps((1,1,1+r2)),"great rhombicuboctahedron":ps((1,1+r2,1+2*r2))}.items():
    h=ConvexHull(P); g={}
    for t,e in zip(h.simplices,h.equations): g.setdefault(tuple(np.round(e[:3],5)),[]).append(t)
    print(name,"V",len(P),"F",len(g),"E",len(P)+len(g)-2)
    out={}
    for n,ts in g.items():
        k=len({v for t in ts for v in t}); om=0
        for t in ts:
            a,b,c=P[t[0]],P[t[1]],P[t[2]]; na,nb,nc=map(np.linalg.norm,(a,b,c))
            om+=2*math.atan2(abs(a@np.cross(b,c)),na*nb*nc+(a@b)*nc+(a@c)*nb+(b@c)*na)
        out.setdefault(k,[]).append(om/(4*math.pi))
    for k in sorted(out): print(f"  {k}-gon x{len(out[k])}: {100*out[k][0]:.2f}% each")
